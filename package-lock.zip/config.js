// config.js
module.exports = {
    host: 'localhost',
    user: 'root',
    password: '12345687',
    database: 'chintans_pharma',
    SECRET_KEY: 'pos_for_pharma'
};
